﻿namespace Hypesoft.Infrastructure;

public class Class1
{

}
