﻿namespace Hypesoft.Domain;

public class Class1
{

}
