﻿namespace Hypesoft.Application;

public class Class1
{

}
