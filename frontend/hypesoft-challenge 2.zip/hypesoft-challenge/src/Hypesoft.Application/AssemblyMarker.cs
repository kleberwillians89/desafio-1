namespace Hypesoft.Application;
public sealed class AssemblyMarker {}
