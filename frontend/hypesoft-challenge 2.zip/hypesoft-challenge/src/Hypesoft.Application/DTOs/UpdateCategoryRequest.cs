namespace Hypesoft.Application.DTOs;

public sealed record UpdateCategoryRequest(string Id, string Name, string? Description);
