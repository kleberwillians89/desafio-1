namespace Hypesoft.Application.DTOs;

public sealed record CategoryResponse(string Id, string Name, string? Description);
