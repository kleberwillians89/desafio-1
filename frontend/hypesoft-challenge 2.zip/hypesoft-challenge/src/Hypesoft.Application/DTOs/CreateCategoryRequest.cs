namespace Hypesoft.Application.DTOs;

public sealed record CreateCategoryRequest(string Name, string? Description);
