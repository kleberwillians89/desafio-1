/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        hypesoft: {
          primary: "#4F46E5",  // indigo-600
          primaryDark: "#3730A3", // indigo-700
          primaryLight: "#6366F1", // indigo-500
          accent: "#F59E0B",   // amber-500 (raio)
          ink: "#0F172A",      // slate-900
          paper: "#0B1020",    // fundo bem escuro
          card: "#0F1529",     // cartões
          line: "#1E293B"      // divisórias
        }
      },
      boxShadow: {
        soft: "0 10px 25px -10px rgba(79,70,229,.35)",
      },
      borderRadius: {
        blob: "1.25rem",
      }
    },
  },
  plugins: [],
};
