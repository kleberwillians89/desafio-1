// src/App.tsx
import { Link, NavLink as RRNavLink, Outlet } from "react-router-dom";

function NavLink({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <RRNavLink
      to={to}
      className={({ isActive }) =>
        `rounded-md px-3 py-1.5 text-sm font-medium ${
          isActive ? "bg-indigo-600 text-white" : "bg-white/5 hover:bg-white/10"
        }`
      }
    >
      {children}
    </RRNavLink>
  );
}

export default function App() {
  return (
    <>
      <header className="sticky top-0 z-10 backdrop-blur border-b border-white/10">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <Link to="/" className="text-2xl font-extrabold">
            Hypesoft Inventory
          </Link>
          <nav className="flex gap-2">
            <NavLink to="/dashboard">Dashboard</NavLink>
            <NavLink to="/products">Produtos</NavLink>
            <NavLink to="/categories">Categorias</NavLink>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        <Outlet />
      </main>
    </>
  );
}
