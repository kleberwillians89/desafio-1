import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:5088";
const API_PREFIX = (import.meta.env.VITE_API_PREFIX ?? "").replace(/\/$/, "");

export const api = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" },
});

export const apiPath = (p: string) =>
  `${API_PREFIX}${p.startsWith("/") ? p : `/${p}`}`;
