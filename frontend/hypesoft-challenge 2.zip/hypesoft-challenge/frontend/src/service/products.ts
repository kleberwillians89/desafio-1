// src/service/products.ts
import { api, apiPath } from "./api";
import type { Product } from "../types";

export type ListProductsParams = {
  page?: number;
  pageSize?: number;
  categoryId?: string;
  q?: string;
};

// Json-server: usa _page e _limit. Devolvemos SEMPRE array.
export async function listProducts(params: ListProductsParams = {}): Promise<Product[]> {
  const query: Record<string, any> = {};
  if (params.page) query._page = params.page;
  if (params.pageSize) query._limit = params.pageSize;
  if (params.categoryId) query.categoryId = params.categoryId;
  if (params.q) query.q = params.q;

  const { data } = await api.get(apiPath("/products"), { params: query });
  return data as Product[];
}

export async function createProduct(payload: Omit<Product, "id" | "categoryName">) {
  const { data } = await api.post(apiPath("/products"), payload);
  return data as Product;
}

export async function deleteProduct(id: string) {
  await api.delete(apiPath(`/products/${id}`));
}
