import { api, apiPath } from "./api";
import type { Category } from "../types";

export async function listCategories(): Promise<Category[]> {
  const { data } = await api.get(apiPath("/categories"));
  return data;
}

export async function createCategory(payload: Omit<Category, "id">) {
  const { data } = await api.post(apiPath("/categories"), payload);
  return data as Category;
}

export async function deleteCategory(id: string) {
  await api.delete(apiPath(`/categories/${id}`));
}
