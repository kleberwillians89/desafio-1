// src/pages/Dashboard.tsx
import { useQuery } from "@tanstack/react-query";
import { listProducts } from "../service/products";
import { listCategories } from "../service/categories";
import type { Product, Category } from "../types";
import { formatBRL } from "../utils/currency";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

function StatCard({ title, value }: { title: string; value: string | number }) {
  return (
    <div className="rounded-xl bg-white/5 p-4 shadow ring-1 ring-white/10">
      <p className="text-sm text-white/70">{title}</p>
      <p className="mt-1 text-2xl font-semibold">{value}</p>
    </div>
  );
}

export default function Dashboard() {
  const { data: products = [] as Product[] } = useQuery({
    queryKey: ["products", "all"],
    queryFn: () => listProducts({ page: 1, pageSize: 1000 }),
  });

  const { data: categories = [] as Category[] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => listCategories(),
  });

  const totalProdutos = products.length;
  const valorTotal = products.reduce((acc, p) => acc + (p.price || 0), 0);
  const baixos = products.filter((p) => (p.stock ?? 0) < 10).length;

  const porCategoria = categories
    .map((c) => ({
      name: c.name,
      value: products.filter((p) => p.categoryId === c.id).length,
    }))
    .filter((d) => d.value > 0);

  const COLORS = ["#6366f1", "#22d3ee", "#f472b6", "#f59e0b", "#10b981", "#ef4444"];

  return (
    <section className="space-y-8">
      <h1 className="text-4xl font-extrabold">Dashboard</h1>

      <div className="grid gap-4 md:grid-cols-3">
        <StatCard title="Total de produtos" value={totalProdutos} />
        <StatCard title="Valor total do estoque" value={formatBRL(valorTotal)} />
        <StatCard title="Baixo estoque (&lt; 10)" value={baixos} />
      </div>

      <div className="rounded-2xl bg-white/5 p-4">
        <h2 className="text-xl font-semibold mb-4">Produtos por categoria</h2>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie dataKey="value" data={porCategoria} outerRadius={110} label>
                {porCategoria.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </section>
  );
}
