// src/pages/ProductsPage.tsx
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { listProducts, createProduct, deleteProduct } from "../service/products";
import { listCategories } from "../service/categories";
import type { Product, Category } from "../types";
import { parseBRL, formatBRL } from "../utils/currency";

type FormValues = {
  name: string;
  price: number | string;
  stock: number;
  categoryId: string;
  description?: string;
};

const schema = z.object({
  name: z.string().min(1, "Informe o nome"),
  price: z.union([z.number(), z.string()]),
  stock: z.coerce.number().int().nonnegative(),
  categoryId: z.string().min(1, "Selecione uma categoria"),
  description: z.string().optional(),
});

export default function ProductsPage() {
  const qc = useQueryClient();

  const { data: categories = [] as Category[] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => listCategories(),
  });

  const { data: products = [] as Product[] } = useQuery({
    queryKey: ["products"],
    queryFn: () => listProducts({ page: 1, pageSize: 1000 }),
  });

  const createMut = useMutation({
    mutationFn: async (values: FormValues) => {
      const payload = {
        name: values.name,
        description: values.description ?? "",
        stock: Number(values.stock) || 0,
        price: typeof values.price === "string" ? parseBRL(values.price) : values.price,
        categoryId: values.categoryId,
      };
      return createProduct(payload);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["products"] }),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteProduct(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["products"] }),
  });

  const { register, handleSubmit, reset } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { name: "", price: 0, stock: 0, categoryId: "" },
  });

  function onSubmit(values: FormValues) {
    createMut.mutate(values, { onSuccess: () => reset() });
  }

  return (
    <section className="space-y-8">
      <h1 className="text-4xl font-extrabold">Produtos</h1>

      <form onSubmit={handleSubmit(onSubmit)} className="grid gap-3 md:grid-cols-2">
        <input className="h-10 rounded-md bg-white/5 px-3" placeholder="Nome" {...register("name")} />
        <input className="h-10 rounded-md bg-white/5 px-3" placeholder="Preço" {...register("price")} />
        <input className="h-10 rounded-md bg-white/5 px-3" placeholder="Estoque" {...register("stock")} />
        <select className="h-10 rounded-md bg-white/5 px-3" {...register("categoryId")}>
          <option value="">Selecione uma categoria</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <input className="md:col-span-2 h-10 rounded-md bg-white/5 px-3" placeholder="Descrição (opcional)" {...register("description")} />
        <div className="md:col-span-2">
          <button
            type="submit"
            disabled={createMut.isPending}
            className="w-full rounded-md bg-gradient-to-r from-indigo-500 to-fuchsia-500 py-2 font-medium disabled:opacity-60"
          >
            {createMut.isPending ? "Adicionando..." : "Adicionar"}
          </button>
        </div>
      </form>

      <table className="w-full text-left">
        <thead className="text-white/70">
          <tr className="border-b border-white/10">
            <th className="py-3">Produto</th>
            <th>Categoria</th>
            <th>Preço</th>
            <th>Estoque</th>
            <th className="text-right">Ações</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => {
            const cat = categories.find((c) => c.id === p.categoryId);
            return (
              <tr key={p.id} className="border-b border-white/5">
                <td className="py-3">{p.name}</td>
                <td>{cat?.name ?? "-"}</td>
                <td>{formatBRL(p.price)}</td>
                <td>{p.stock}</td>
                <td className="text-right">
                  <button
                    onClick={() => deleteMut.mutate(p.id)}
                    className="rounded-md bg-white/10 px-3 py-1 hover:bg-white/20"
                  >
                    Remover
                  </button>
                </td>
              </tr>
            );
          })}
          {products.length === 0 && (
            <tr>
              <td colSpan={5} className="py-6 text-center text-white/60">
                Nenhum produto
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </section>
  );
}
