import React from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import type { Category } from "../types";
import { listCategories, createCategory, deleteCategory } from "../service/categories";

const schema = z.object({
  name: z.string().min(2, "Informe um nome"),
  description: z.string().optional(),
});
type FormValues = z.infer<typeof schema>;

export default function CategoriesPage() {
  const qc = useQueryClient();

  const { data, isLoading, error } = useQuery<Category[]>({
    queryKey: ["categories"],
    queryFn: listCategories,
  });

  const createMut = useMutation({
    mutationFn: (v: FormValues) => createCategory(v),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["categories"] }),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteCategory(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["categories"] }),
  });

  const { register, handleSubmit, reset, formState } = useForm<FormValues>({
    resolver: zodResolver(schema),
  });

  const onSubmit = (v: FormValues) => {
    createMut.mutate(v, { onSuccess: () => reset() });
  };

  return (
    <section className="space-y-8">
      <div>
        <h1 className="h1">Categorias</h1>
        <p className="subtle">Crie e gerencie categorias para seus produtos.</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <input className="input" placeholder="Nome da categoria" {...register("name")} />
        <input className="input" placeholder="Descrição (opcional)" {...register("description")} />
        <button className="btn btn-primary" type="submit" disabled={createMut.isPending}>
          {createMut.isPending ? "Salvando..." : "Adicionar"}
        </button>

        {formState.errors.name && (
          <span className="text-red-400 md:col-span-3">{formState.errors.name.message}</span>
        )}
      </form>

      <div className="overflow-x-auto">
        <table className="table">
          <thead>
            <tr>
              <th>Nome</th>
              <th className="hidden md:table-cell">Descrição</th>
              <th className="w-40">Ações</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr><td colSpan={3} className="py-6 subtle">Carregando…</td></tr>
            )}

            {error && (
              <tr>
                <td colSpan={3} className="py-6 text-red-400">
                  Erro ao carregar categorias. Verifique VITE_API_URL/VITE_API_PREFIX.{" "}
                  <span className="subtle">({(error as any)?.message ?? "sem detalhes"})</span>
                </td>
              </tr>
            )}

            {!isLoading && !error && data?.map((c: Category) => (
              <tr key={c.id} className="border-b border-hypesoft-line/50">
                <td className="py-3">{c.name}</td>
                <td className="py-3 hidden md:table-cell">{c.description || "-"}</td>
                <td className="py-3">
                  <button
                    className="btn btn-danger"
                    onClick={() => deleteMut.mutate(c.id)}
                    disabled={deleteMut.isPending}
                  >
                    Remover
                  </button>
                </td>
              </tr>
            ))}

            {!isLoading && !error && (data?.length ?? 0) === 0 && (
              <tr><td colSpan={3} className="py-6 subtle">Nenhuma categoria ainda.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
