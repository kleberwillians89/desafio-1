// src/utils/currency.ts
const nfBRL = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  maximumFractionDigits: 2,
});

export function formatBRL(value: number | string) {
  const n = typeof value === "string" ? Number(value.replace(/\./g, "").replace(",", ".")) : value;
  return nfBRL.format(Number.isFinite(n) ? n : 0);
}

export function parseBRL(text: string | number): number {
  if (typeof text === "number") return text;
  const cleaned = text.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}(?:\D|$))/g, "");
  const normalized = cleaned.replace(",", ".");
  const n = Number(normalized);
  return Number.isFinite(n) ? n : 0;
}
